﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fadwa_h.w1
{
    public partial class Form10 : Form
    {
         
        public Form10()
        {
            InitializeComponent();
        }
        public void UpdateData(int index, string num1, string operation, string num2,
string result)
        {
            if (index >= 0 && index < listBox1.Items.Count)
            {
                listBox1.Items[index] = num1;
                listBox2.Items[index] = operation;
                listBox3.Items[index] = num2;
                listBox4.Items[index] = result;
            }
        }
        private void SyncListBoxes(object sender, EventArgs e)
        {
            ListBox selectedListBox = sender as ListBox;
            int selectedIndex = selectedListBox.SelectedIndex;

            listBox1.SelectedIndex = selectedIndex;
            listBox2.SelectedIndex = selectedIndex;
            listBox3.SelectedIndex = selectedIndex;
            listBox4.SelectedIndex = selectedIndex;
        } 

        private void button4_Click(object sender, EventArgs e)
        {
            int selectedIndex = listBox1.SelectedIndex; 
 
            if(selectedIndex != -1) 
            { 
                Form12 form12 = new Form12
                { 
                    Num1 = listBox1.Items[selectedIndex].ToString(), 
                    Operation = listBox2.Items[selectedIndex].ToString(), 
                    Num2 = listBox3.Items[selectedIndex].ToString(), 
                    Result = listBox4.Items[selectedIndex].ToString(), 
                    SelectedIndex = selectedIndex, 
                }; 
 
                form12.ShowDialog(); 
                if(form12.IsUpdated) 
                { 
                    UpdateData(selectedIndex, form12.Num1, form12.Operation, form12.Num2, 
form12.Result); 
                } 
            } 
            else 
            {
                MessageBox.Show("هيلع ليدعتلل  رصنع  رايتخا ىجري.");
            } 
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("+");
            comboBox1.Items.Add("-");
            comboBox1.Items.Add("*");
            comboBox1.Items.Add("/");
            listBox1.SelectedIndexChanged += SyncListBoxes;
            listBox2.SelectedIndexChanged += SyncListBoxes;
            listBox3.SelectedIndexChanged += SyncListBoxes;
            listBox4.SelectedIndexChanged += SyncListBoxes;

            listBox1.Items.Add("7");
            listBox2.Items.Add("+");
            listBox3.Items.Add("7");
            listBox4.Items.Add("14");
            listBox1.Items.Add("90");
            listBox2.Items.Add("/");
            listBox3.Items.Add("10");
            listBox4.Items.Add("9");

            listBox1.Items.Add("20");
            listBox2.Items.Add("*");
            listBox3.Items.Add("2");
            listBox4.Items.Add("40");

            listBox1.Items.Add("35");
            listBox2.Items.Add("-");
            listBox3.Items.Add("35");
            listBox4.Items.Add("0"); 
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
             if(listBox1.SelectedItem != null) 
            { 
                DialogResult result = MessageBox.Show(".","هل انت متأكد من حذف هذا العنصر", MessageBoxButtons.YesNo, MessageBoxIcon.Warning); 
                if(result == DialogResult.Yes) 
                { 
                    int selectedIndex = listBox1.SelectedIndex; 
                    listBox1.Items.RemoveAt(selectedIndex); 
                    listBox2.Items.RemoveAt(selectedIndex); 
                    listBox3.Items.RemoveAt(selectedIndex); 
                    listBox4.Items.RemoveAt(selectedIndex); 
                } 
            } 
            else 
            { 
                MessageBox.Show("حدد العنصر المراد حذفه"); 
            } 

        }

        private void button3_Click(object sender, EventArgs e)
        {
             DialogResult result = MessageBox.Show("تاكيد" ,"هل انت متاكد من حذف جميع العناصر", MessageBoxButtons.YesNo, MessageBoxIcon.Warning); 
            if(result == DialogResult.Yes) 
            { 
                listBox1.Items.Clear(); 
                listBox2.Items.Clear(); 
                listBox3.Items.Clear(); 
                listBox4.Items.Clear(); 
            } 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) ||
                string.IsNullOrWhiteSpace(comboBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("يرجى ملء جميع الحقول");
                return;
            }

            float num1;
            if (!float.TryParse(textBox1.Text, out num1))
            {
                MessageBox.Show("يرجى ادخال رقم صحيح في الحقل الاول");
                return;
            }

            float num2;
            if (!float.TryParse(textBox2.Text, out num2))
            {
                MessageBox.Show("يرجى ادخال رقم صحيح في الحقل الثالث");
                return;
            }

            float result = 0;
            switch (comboBox1.Text)
            {
                case "+":
                    result = num1 + num2;
                    break;
                case "-":
                    result = num1 - num2;
                    break;
                case "*":
                    result = num1 * num2;
                    break;
                case "/":
                    if (num2 != 0)
                    {
                        result = num1 / num2;
                    }
                    else
                    {
                        MessageBox.Show("لا يمكن القسمة على صفر.");
                        return;
                    }
                    break;
                default:
                    MessageBox.Show("يرجى اختيار عملية صحيحة");
                    return;
            }
            textBox3.Text = result.ToString(); 

            listBox1.Items.Add(num1.ToString()); 
            listBox2.Items.Add(comboBox1.Text);
            listBox3.Items.Add(num2.ToString());
            listBox4.Items.Add(textBox3.Text);
        }
    }
}
