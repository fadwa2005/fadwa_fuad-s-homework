﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fadwa_h.w1
{
    public partial class Form9 : Form
    {

        private void SyncListBoxes(object sender, EventArgs e)
        {
            ListBox selectedListBox = sender as ListBox;
            int selectedIndex = selectedListBox.SelectedIndex;
            listBox1.SelectedIndex = selectedIndex;
            listBox2.SelectedIndex = selectedIndex;
            listBox3.SelectedIndex = selectedIndex;
            listBox4.SelectedIndex = selectedIndex;
        } 
        public Form9()
        {
            InitializeComponent();
            listBox1.SelectedIndexChanged += SyncListBoxes;
            listBox2.SelectedIndexChanged += SyncListBoxes;
            listBox3.SelectedIndexChanged += SyncListBoxes;
            listBox4.SelectedIndexChanged += SyncListBoxes; 
        }

        private void Form9_Load(object sender, EventArgs e)
        {

            listBox1.Items.Add("124");
            listBox2.Items.Add(" محمد فؤاد");
            listBox3.Items.Add("12");
            listBox4.Items.Add("ذكر");

            listBox1.Items.Add("245");
            listBox2.Items.Add("شهاب فؤاد");
            listBox3.Items.Add("15");
            listBox4.Items.Add("ذكر");

            listBox1.Items.Add("124");
            listBox2.Items.Add("فدوى فؤاد");
            listBox3.Items.Add("19");
            listBox4.Items.Add("انثى"); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox3.Text))
            {
                MessageBox.Show("يرجى ملء جميع الحقول");
                return;
            }

            int inputNumber;
            if (!int.TryParse(textBox1.Text, out inputNumber))
            {
                MessageBox.Show("يرجى ادخال عمر صحيح في الحقل الاول");
                return;
            }

            int age;
            if (!int.TryParse(textBox3.Text, out age))
            {
                MessageBox.Show("يرجى ادخال عمر صحيح في الحقل الثالث");
                return;
            }

            listBox1.Items.Add(inputNumber.ToString());
            listBox2.Items.Add(textBox2.Text);
            listBox3.Items.Add(age.ToString());
            listBox4.Items.Add(radioButton1.Checked ? "انثى" : "ذكر");

            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            radioButton1.Checked = false;
            radioButton2.Checked = false; 
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int selectedIndex = listBox1.SelectedIndex;
            if (selectedIndex != -1)
            {
                Form11 f = new Form11();
                f.Item1 = listBox1.Items[selectedIndex].ToString();
                f.Item2 = listBox2.Items[selectedIndex].ToString();
                f.Item3 = listBox3.Items[selectedIndex].ToString();
                f.Gender = listBox4.Items[selectedIndex].ToString();

                if (f.ShowDialog() == DialogResult.OK)
                {
                    listBox1.Items[selectedIndex] = f.Item1;
                    listBox2.Items[selectedIndex] = f.Item2;
                    listBox3.Items[selectedIndex] = f.Item3;
                    listBox4.Items[selectedIndex] = f.Gender;
                }
            }
            else
            {
                MessageBox.Show("يرجى اختيار عنصر للتعديل علية");
            } 
        }

        private void button3_Click(object sender, EventArgs e)
        {
             
            DialogResult result = MessageBox.Show("تأكيد" ,"هل انت متأكد من مسح جميع العناصر", MessageBoxButtons.YesNo, MessageBoxIcon.Warning); 
            if(result == DialogResult.Yes) 
            { 
                listBox1.Items.Clear(); 
                listBox2.Items.Clear(); 
                listBox3.Items.Clear(); 
                listBox4.Items.Clear(); 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(listBox1.SelectedItem != null) 
            { 
                DialogResult result = MessageBox.Show(" ,","هل انت متاكد انك تريد حذف هذا العنصر", MessageBoxButtons.YesNo, MessageBoxIcon.Warning); 
                if(result == DialogResult.Yes) 
                { 
                    int selectedIndex = listBox1.SelectedIndex; 
                    listBox1.Items.RemoveAt(selectedIndex); 
                    listBox2.Items.RemoveAt(selectedIndex); 
                    listBox3.Items.RemoveAt(selectedIndex); 
                    listBox4.Items.RemoveAt(selectedIndex); 
                } 
            } 
            else 
            { 
                MessageBox.Show("يرجى تحديد عنصر لحذفة"); 
            } 
        }

        private void Form9_MouseDown(object sender, MouseEventArgs e)
        {
            listBox1.ClearSelected(); 
            listBox2.ClearSelected(); 
            listBox3.ClearSelected(); 
            listBox4.ClearSelected(); 
            this.ActiveControl = null; 
            radioButton1.Checked = false; 
            radioButton2.Checked = false;  
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
