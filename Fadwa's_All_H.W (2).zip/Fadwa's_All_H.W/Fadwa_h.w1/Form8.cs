﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fadwa_h.w1
{
    public partial class Form8 : Form
    {

        List<int> numbers = new List<int>(); 
        public Form8()
        {
            InitializeComponent();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            } 
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            textBox2.KeyPress += textBox1_KeyPress;
            Random random = new Random();
            while (numbers.Count < 10)
            {
                int randomNumber = random.Next(1, 101);
                if (!numbers.Contains(randomNumber))
                {
                    numbers.Add(randomNumber);
                }
            }
            UpdateList();
            button1.Enabled = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            button1.Enabled = !string.IsNullOrWhiteSpace(textBox1.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int number = int.Parse(textBox1.Text.Trim());
            if (number <= 100)
            {
                if (!numbers.Contains(number))
                {
                    numbers.Add(number);
                    if (numbers.Count > 20)
                    {
                        numbers.RemoveAt(0);
                    }
                    UpdateList();
                }
                else
                {
                    MessageBox.Show("الرقم موجود مسبقاً في القائمة");
                }
            }
            else
            {
                MessageBox.Show("100 ادخل رقم اقل من او يساوي");
            }

            textBox1.Clear(); 
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (listBox1.SelectedItem != null)
            {
                int selectedNumber = int.Parse(listBox1.SelectedItem.ToString());
                numbers.Remove(selectedNumber);
                UpdateList();
            } 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            numbers.Clear();
            UpdateList();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int sum = numbers.Sum();
            textBox3.Text = sum.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (numbers.Count > 0)
            {
                double average = numbers.Average();
                textBox2.Text = average.ToString("0.##");
            }
        }
        private void UpdateList()
        {
            listBox1.Items.Clear();
            foreach (var number in numbers.Take(20))
            {
                listBox1.Items.Add(number);
            }
        }
    }
}
