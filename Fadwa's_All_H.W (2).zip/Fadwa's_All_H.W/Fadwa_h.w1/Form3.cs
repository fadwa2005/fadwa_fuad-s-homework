﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fadwa_h.w1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
            //    e.Handled = true;
            if ((e.KeyChar > 57 || e.KeyChar < 48) && (e.KeyChar != 8) && (e.KeyChar != 45) && (e.KeyChar != 44))
                e.Handled = true;
            else
                e.Handled = false;
            if (e.KeyChar == 45 && ((sender as TextBox).SelectionStart != 0 || (sender as TextBox).Text.Contains("-")))
                e.Handled = true;
            if (e.KeyChar == 44 && ((sender as TextBox).SelectionStart == 0 || (sender as TextBox).Text.Contains(",")))
                e.Handled = true;
        }
        //زر ايجاد المضروب------------------------------------------------
        private void button2_Click(object sender, EventArgs e)
        {
            //try 
            //{
            //    int number =int.Parse(textBox1.Text);
            //    if(number<0)
            //    {
            //        label2.Text="ENTER NUMBER";
            //        return;
            //    }
            //    long factorial=cal(number);
            //    label2.Text=$"fact:{factorial}";
            //}
            //    catch(FormatException)
            //{label2.Text="enter namber";}
            //catch(Exception ex)
            //{
            //    label2.Text=$"sa{ex.message}";
            //}

            int x = Convert.ToInt32(textBox1.Text);
            label3.Text = Convert.ToString(cal(x));
            if (textBox1.Text == "")
                MessageBox.Show("ادخل العدد!");
        }
        //دوال المجموع والمضروب----------------------------------------------------------
        private long cal(int n)
        { 
            if (n==0|| n==1)
        return 1;
        long result=1;
        for (int i=2;i<=n;i++)
            {
                result*=i;
            }
        return result;
        }
        private long sum(int n)
        {
            if (n == 0 || n == 1)
                return 1;
            long result = 1;
            for (int i = 2; i <= n; i++)
            {
                result += i;
            }
            return result;
        }
        //private long sqrt(int n)
        //{
        //    double sqrt = Math.Sqrt(n);
        //}
        //زر ايجاد المجموع----------------------------------------------------------------
        private void button1_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(textBox1.Text);
            label2.Text = Convert.ToString(sum(x));
            if (textBox1.Text == "")
                MessageBox.Show("ادخل العدد!");
        }
        
        //زر ايجاد الجذر--------------------------------------------------------------------------
        private void button3_Click(object sender, EventArgs e)
        {
            //int x = Convert.ToInt32(textBox1.Text);
            //label4.Text = Convert.ToString(sqrt(x));

            //try
            //{
            //    double number=double.Parse(textBox1.Text);
            //    if (number<0)
            //    {
            //        label4.Text="";
            //        return;
            //    }
            //    double sqrt =Math.Sqrt(number);
            //    label4.Text=$"{sqrt:F2}";
            //}
            //    catch(FormatException)
            //{
            //       label4.Text="";
            //    }
            //catch(Exception ex)
            //{
            //    label4.Text=$"{ex.Message}";
            //}
            double x = Convert.ToDouble(textBox1.Text);
            if (x >= 0)
            {
                for (int i = 0; i <= x; i++)
                    if (i * i == x)
                        label4.Text = i.ToString();
                    else
                        label4.Text = (Math.Sqrt(x)).ToString();
            }
            else
            {
                x = 1 * -x;
                if (x == 1)
                    label4.Text = "i";
                else
                    label4.Text = "i*" + Convert.ToString(Math.Sqrt(x));
            }


        }

        private void Form3_Load(object sender, EventArgs e)
        {
            button1.Enabled = button2.Enabled = button3.Enabled = false;
            textBox1.Focus();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != null)
                button1.Enabled = button2.Enabled = button3.Enabled = true;
            else
                button1.Enabled = button2.Enabled = button3.Enabled = false;
        }

    }
}
