﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fadwa_h.w1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        private void traingforsender(object sender, EventArgs e)
        {
            //if (sender == button2)
            //{
            //    button1.BackColor = Color.Yellow;
            //    MessageBox.Show("تم اختيارتغير الخلفية الى اللون الاصفر");
            //}
            //else if (sender == button4)
            //{
            //    button1.BackColor = Color.Red;
            //    MessageBox.Show("تم اختيارتغير الخلفية الى اللون الاحمر");
            //}
            //else if (((Button)sender).Text == button3.Text)
            //{
            //    button1.BackColor = Color.Green;
            //    MessageBox.Show("تم اختيارتغير الخلفية الى اللون الاخضر");
            //}
            //else if (((Label)sender).Text == "جهاز1")
            //    button1.Text = label1.Text;
            //else if (sender == label2)
            //    button1.Text = label2.Text;
            Button bt = sender as Button;
            Label la = sender as Label;
            if (bt != null && bt.Text == button4.Text)// Button ليست من نوع sender لن يحدث إستثناء وإنما سيعيد قيمة فارغة إذا كانت ال 
                button1.BackColor = Color.Red;
            else if (bt != null && bt.Text == button2.Text)
                button1.BackColor = Color.Yellow;
            else if (bt != null && bt.Text == button3.Text)
                button1.BackColor = Color.Green;
            else if (la != null && la.Text == label2.Text)
                button1.Text = label2.Text;
            else if (la != null && la.Text == "DEVICE_1")
                button1.Text = label1.Text;
        }

        private void label1_Click_1(object sender, EventArgs e)
        {
            Label clickedlabel = (Label)sender;
            button1.Text = clickedlabel.Text;
        }

        private void label2_Click_1(object sender, EventArgs e)
        {
            Label clickedlabel = (Label)sender;
            button1.Text = clickedlabel.Text;
        }
    }
}
