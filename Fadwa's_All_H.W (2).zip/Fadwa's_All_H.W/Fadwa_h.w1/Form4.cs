﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fadwa_h.w1
{
    public partial class Form4 : Form
    {
        double x, y, z;
        string[] op = { "+", "-", "*", "/" };
        public Form4()
        {
            InitializeComponent();
            listBox1.Items.Add("+");
            listBox1.Items.Add("-");
            listBox1.Items.Add("*");
            listBox1.Items.Add("/");
            listBox1.SelectedIndex = 0;
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            listBox1.Enabled = false;
            textBox2.TextChanged += textBox1_TextChanged;
            textBox3.ReadOnly = true;
            textBox2.KeyPress += textBox1_KeyPress;
            textBox1.Focus();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8))
                e.Handled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox2.Text = textBox3.Text = null;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


                try { x = Convert.ToDouble(textBox1.Text); }
                catch (Exception)
                {
                  //  MessageBox.Show("تحذير", "العدد الاول غير صحيح", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    textBox1.Text = "";
                    textBox1.Focus();
                    return;
                }
                try { y = Convert.ToDouble(textBox2.Text); }
                catch (Exception)
                {
                    MessageBox.Show("تحذير", "العدد الثاني غير صحيح", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    textBox2.Text = "";
                    textBox2.Focus();
                    return;
                }
                bool f = true;
                switch (listBox1.SelectedIndex)
                {
                    default: break;
                    case 0: z = x + y; break;
                    case 1: z = x - y; break;
                    case 2: z = x * y; break;
                    case 3:
                        if (y != 0)
                        { z = x / y; break; }
                        else
                        {
                            MessageBox.Show("");
                            f = false;
                            textBox3.Text = null;
                            break;
                        }
                }
                if (f)
                    textBox3.Text = z.ToString();
            

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() != "" && textBox2.Text.Trim() != "")
                listBox1.Enabled = true;
            else
                listBox1.Enabled = false;
        }

    }
}
