﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fadwa_h.w1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double n1, n2, n3;
            string op1 = textBox2.Text;
            string op2 = textBox4.Text;
            string s = " ";
            string z = " ";
            if (double.TryParse(textBox1.Text, out n1) &&
                double.TryParse(textBox3.Text, out n2) &&
                double.TryParse(textBox5.Text, out n3))
            {
                if ((op1 != "+" && op1 != "-") || (op2 != "/" && op2 != "*"))
                {
                    s = opp(n1, n2, op1).ToString();
                    if (s == "NaN")
                    {
                        MessageBox.Show("العملية الاولى غير صحيحة");
                        textBox2.Focus();
                        return;
                    }
                    z =
                        opp(Convert.ToDouble(s), n3, op2).ToString();
                    if (z == "NaN")
                    {
                        MessageBox.Show("العملية الثانية غير صحيحة");
                        textBox4.Focus();
                        return;
                    }

                    textBox6.Text = z.ToString();
                }
                else
                {
                    s = opp(n2, n3, op2).ToString();
                    if (s == "NaN")
                    {
                        MessageBox.Show("العملية الثانية غير صحيحة");
                        textBox4.Focus();
                        return;
                    }
                    z =
                        opp(Convert.ToDouble(s), n3, op2).ToString();
                    if (z == "NaN")
                    {
                        MessageBox.Show("العملية الاولى غير صحيحة");
                        textBox2.Focus();
                        return;
                    }

                    textBox6.Text = z.ToString();
                }
            }
            else
            {
                MessageBox.Show("يرجى ادخال ارقام صحيحة");

            }
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private double opp(double num1, double num2, string operation)
        {
            switch (operation)
            {
                case "+":
                    return num1 + num2;
                case "-":
                    return num1 - num2;
                case "*":
                    return num1 * num2;
                case "/":
                    return num2 != 0 ? num1 / num2 : double.NaN;
                default:
                    return double.NaN;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox6.ReadOnly = true;
            textBox3.KeyPress += textBox1_KeyPress;
            textBox5.KeyPress += textBox1_KeyPress;
            button1.Enabled = false;
            textBox5.TextChanged += textBox1_TextChanged;
            textBox3.TextChanged += textBox1_TextChanged;
            textBox2.TextChanged += textBox1_TextChanged;
            textBox4.TextChanged += textBox1_TextChanged;
            textBox4.KeyPress += textBox2_KeyPress;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8))
                e.Handled = true;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if ((textBox1.Text.Trim() != "") && (textBox3.Text.Trim() != "") && (textBox5.Text.Trim() != "") && (textBox2.Text.Trim() != "") && (textBox4.Text.Trim() != ""))
            {
                button1.Enabled = true;
            }
            else
                button1.Enabled = false;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar != '+') && (e.KeyChar != '/') && (e.KeyChar != '*') && (e.KeyChar != '-') && (e.KeyChar != 8))
                e.Handled = true;
            if ((e.KeyChar == '-') && ((sender as TextBox).SelectionStart != 0) || ((e.KeyChar == '+') && ((sender as TextBox).SelectionStart != 0)) || (e.KeyChar == '*') && ((sender as TextBox).SelectionStart != 0) || (e.KeyChar == '/') && ((sender as TextBox).SelectionStart != 0))
                e.Handled = true;
        }
    }
}
