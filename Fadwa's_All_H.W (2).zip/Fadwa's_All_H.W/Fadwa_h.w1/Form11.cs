﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fadwa_h.w1
{
    public partial class Form11 : Form
    {
        public string Item1
        {
            get;
            set;
        }
        public string Item2
        {
            get;
            set;
        }
        public string Item3
        {
            get;
            set;
        }
        public string Gender
        {
            get;
            set;
        }
        public Form11()
        {
            InitializeComponent();
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            textBox1.Text = Item1;
            textBox2.Text = Item2;
            textBox3.Text = Item3;
            if (Gender == " ذكر")
                radioButton1.Checked = true;
            else
                radioButton2.Checked = true;

        }

        private void button5_Click(object sender, EventArgs e)
        {
            int number1;
            if (string.IsNullOrWhiteSpace(textBox1.Text) || !int.TryParse(textBox1.Text,out number1))
            {
                MessageBox.Show("يرجى ادخال رقم صحيح في الحقل الاول");
                textBox1.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("يرجى ادخال رقم في الحقل الحقل الثاني");
                textBox2.Focus();
                return;
            }
            int age;
            if (string.IsNullOrWhiteSpace(textBox3.Text) || !int.TryParse(textBox3.Text, out age))
            {
                MessageBox.Show("يرجى ادخال رقم صحيح في الحقل الثالث");
                textBox3.Focus();
                return;
            }
            if (!radioButton1.Checked && !radioButton2.Checked)
            {
                MessageBox.Show("يرجى تحديد الجنس");
                return;
            }
            Item1 = textBox1.Text;
            Item2 = textBox2.Text;
            Item3 = textBox3.Text;
            Gender = radioButton1.Checked ? "انثى" : "ذكر";
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
