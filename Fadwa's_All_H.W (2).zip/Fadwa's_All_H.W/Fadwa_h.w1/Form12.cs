﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fadwa_h.w1
{
    public partial class Form12 : Form
    {
        public string Num1
        {
            get;
            set;
        }
        public string Operation
        {
            get;
            set;
        }
        public string Num2
        {
            get;
            set;
        }
        public string Result
        {
            get;
            set;
        }
        public int SelectedIndex
        {
            get;
            set;
        }
        public bool IsUpdated
        {
            get;
            set;
        } 
        public Form12()
        {
            InitializeComponent();
        }

        private void Form12_Load(object sender, EventArgs e)
        {   textBox1.Text = Num1; 
            comboBox1.Text = Operation; 
            textBox2.Text = Num2; 
            comboBox1.Items.Add("+"); 
            comboBox1.Items.Add("-"); 
            comboBox1.Items.Add("*"); 
            comboBox1.Items.Add("/");
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) ||
               string.IsNullOrWhiteSpace(comboBox1.Text) ||
               string.IsNullOrWhiteSpace(textBox3.Text))
            {
                MessageBox.Show("يرجى ملىء جميع الحقول");
                return;
            }

            Num1 = textBox1.Text;
            Num2 = textBox3.Text;
            Operation = comboBox1.Text;

            IsUpdated = true;
            this.Close(); 
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1.Text) &&
!string.IsNullOrWhiteSpace(textBox3.Text))
            {
                Num1 = textBox1.Text;
                Num2 = textBox3.Text;
                Operation = comboBox1.Text;

                Result = CalculateResult();
            }
        }
        private string CalculateResult()
        {
            float num1 = float.Parse(Num1);
            float num2 = float.Parse(Num2);

            switch (Operation)
            {
                case "+":
                    return (num1 + num2).ToString();
                case "-":
                    return (num1 - num2).ToString();
                case "*":
                    return (num1 * num2).ToString();
                case "/":
                    if (num2 != 0)
                    {
                        return (num1 / num2).ToString();
                    }
                    else
                    {
                        MessageBox.Show(" لا يمكن القسمة على صفر");
                        return "خطأ";
                    }
                default:
                    MessageBox.Show("يرجى اختيار عملية صحيحة");
                    return "خطأ";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        } 
    }
}
