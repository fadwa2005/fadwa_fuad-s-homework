﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fadwa_h.w1
{
    public partial class Form7 : Form
    {
        private Stack<TextState> undoStack = new Stack<TextState>();
        private Stack<TextState> redoStack = new Stack<TextState>();
        private bool isUndoRedoOperation = false;
        public Form7()
        {
            InitializeComponent();
        }

        private class TextState
        {
            public string SourceText
            {
                get;
                set;
            }
            public string DestinationText
            {
                get;
                set;
            }

            public TextState(string sourceText, string destinationText)
            {
                SourceText = sourceText;
                DestinationText = destinationText;
            }

        }
        private void SaveState()
        {
            if (!isUndoRedoOperation)
            {
                undoStack.Push(new TextState(textBox2.Text, textBox1.Text));
                redoStack.Clear();
            }
        }
        private void TextChangedHandler(object sender, EventArgs e)
        {
            SaveState();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            textBox2.TextChanged += new EventHandler(TextChangedHandler);
            textBox1.TextChanged += new EventHandler(TextChangedHandler);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox2.SelectedText))
            {
                Clipboard.SetText(textBox2.SelectedText);
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox2.SelectedText))
            {
                SaveState();
                Clipboard.SetText(textBox2.SelectedText);
                textBox2.SelectedText = "";
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (Clipboard.ContainsText())
            {
                SaveState();
                textBox1.Text += Clipboard.GetText();
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if (undoStack.Count > 1)
            {
                isUndoRedoOperation = true;
                redoStack.Push(undoStack.Pop());
                TextState previousState = undoStack.Peek();

                textBox2.Text = previousState.SourceText;
                textBox1.Text = previousState.DestinationText;

                isUndoRedoOperation = false;
            }
        }

    }
}
